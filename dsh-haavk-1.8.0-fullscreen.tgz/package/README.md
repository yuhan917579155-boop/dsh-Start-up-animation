# dsh-haavk

DeepSeek Harness 的启动界面与启动动画插件。

> **⚠️ 二次开发声明**　本项目是**二次开发作品**，底座来自
> [6shenhonghong9/dsh-startup-screen](https://github.com/6shenhonghong9/dsh-startup-screen)（MIT，**v1.1.1**，作者**沈宏宏**）。
> 上游的许可证全文与原作者署名**完整保留**；本仓库以 MIT 发布，
> 但**不覆盖**哈夫克 / HAAVK /《三角洲行动》相关素材与商标（权利归腾讯 / 天美）。
> 完整声明见 [NOTICE](NOTICE)。

**哈夫克全域互联终端**（《三角洲行动》哈夫克阵营开机画面）：浅蓝白斜切几何底 →
左列菱形徽记与 HAAVK 字标 → 右列标题与八行逐行点亮的系统清单 → 五步访问授权推进 →
分层退场 + 徽记落印 + WELCOME 交叉淡入 → 整片浅色场溶解回应用。

配色只用哈夫克蓝白（主蓝 `#2362af` / 亮蓝 `#5b96dd` / 深蓝 `#16324f`），
全站统一，不再有暖白与橙。

底板三档色（`--p-plane-t` / `--p-plane-m` / `--p-plane-b`）和斜切带
（`--p-facet-rgb`）不是估的：把参考画面切成网格逐格取色反解出来的 ——
上缘亮度约 215、蓝差 `b-r` 约 +27，中段 222 / +18，底部 230 / +7，
也就是整幅只在纵向上走一道很缓的「上冷下暖、上深下浅」，横向几乎不渐变。
横向再加强一点就会读成一张渐变卡，而不是真实终端画面。

---

## 截图

**网页层**（插件注入，冷启动时播放）

| 开场 · 徽记落墨 | 清单逐行点亮 · 进度推进 |
|---|---|
| ![开场](docs/img/web-01-entry.png) | ![进度](docs/img/web-02-progress.png) |
| **全亮 · 终端全貌** | **终幕 · 欢迎屏** |
| ![全貌](docs/img/web-03-full.png) | ![终幕](docs/img/web-04-finale.png) |
| **深色主题** | **回退序列 · 黑幕揭幕** |
| ![深色](docs/img/web-05-dark.png) | ![黑幕](docs/img/web-06-dmark.png) |

**原生层**（桌面端 `Resources/splash.html`，插件注入不到，需覆盖文件）

![原生启动壳](docs/img/native-light.png)

截图取自本仓库的离线预览页与真实渲染，均为浅蓝 · 哈夫克终端主题。

---

## 文档导航

| 文档 | 讲什么 |
|---|---|
| **[docs/GUIDE.md](docs/GUIDE.md)** | 使用说明：三种装法与 Windows 专节、30 项设置逐条解释、桌面端、出问题怎么查 |
| [docs/ABOUT.md](docs/ABOUT.md) | 项目介绍：这个终端画面是怎么来的、设计取舍 |
| [docs/UPSTREAM-DIFF.md](docs/UPSTREAM-DIFF.md) | 与原版（v1.1.1）的逐项差异清单 |
| **[NOTICE](NOTICE)** | **二次开发声明：上游署名、许可范围、不覆盖的第三方素材** |
| [DESKTOP.md](DESKTOP.md) | 桌面端原生启动壳：覆盖命令、签名、限制 |
| [INSTALL.md](INSTALL.md) | 手工安装 / 离线安装 / 重复注册排查 |
| [AUDIO-FIELDS.md](AUDIO-FIELDS.md) | 音频素材槽位协议（想换配音看这个） |
| [preview/index.html](preview/index.html) | 离线预览页，不装插件也能看完整动画 |

---

## 功能

**开机序列**　冷启动时播一段完整的开机动画：终端画面淡入 → 八行系统清单按五步授权
逐行点亮 → 底部 `55ms` / `CN UID` 状态条与全宽细进度线同步推进 → 收尾。
清单文案：正在遍历员工级别矩阵 / 正在启动员工效率监控系统 / 正在校准全域信号阵列 /
正在预热脑机接口 / 正在计算可接受损失 / 正在抑制不必要变量 /
每一秒，都在投资未来…… / 请稍候，进一步需要时间……

**全程都在动**　没有一处是「开关式」显隐：徽记 1.4s 描边后落墨、外圈虚线环 34s 慢转、
字标逐字母升起、清单逐字浮出、刚点亮那行带光标、进度条用 rAF 追值（只进不退）且两幕之间
有渗流补帧、`55ms` 读数逐帧压到位、八行十六进制数据流滚动扫过、全场还有一道极缓的扫描光带。

**过渡不留硬切**　这一版专门治「每一处过渡都像切屏」：
徽记描边跑完后不是直接变实心，而是 `fill-opacity` / `stroke-width` 各自过渡 900ms，
线框与实心并存那半秒正是「墨顺着轮廓渗进去」；
状态条与计数换字时旧字就地变残影飘走、新字新建元素浮上来（不再清空重排）；
数据流换内容也不重启动画，滚动接着走，不会每步「跳回顶部」。
所有逐帧动画只碰 `transform` / `opacity`（状态格原本动画 `background`，已改）；
常驻无限动画不再挂 `will-change`，合成层不会越积越多。
实测 949 帧的进度采样里，最差一帧 16.8ms —— 没有超过 16.8ms 的帧。

**徽记更大，空白有人填**　徽记从 38vh 放大到 46vh（`clamp(230px, 46vh, 520px)`），
字标同档放大，光晕改用独立径向层（不再用 `drop-shadow` 滤镜，滤镜每帧重算最贵）。
原先空着的地方补进来：左下 `LINK SIGNAL` 实时波形、右下 `NODE MATRIX` 状态格、
贯穿全底的滚动播报带、徽记背后的雷达扫描弧与缓慢旋转的虚线环。

**退场是「换景」，不是「消失」**　内容整体包在 `.dsu-t-stage` 里，退场时这一层
缓慢推近到 1.035 并淡出（背景斜切面与网格不动）→ 有空间深度；
同时 `.dsu-t-finale` 的同心环、十字准星、上下两道读数线先淡进来占住画面，
WELCOME 落进去时不会掉进一片空场。徽记退到七成时 WELCOME 已经开始起，
两者擦身而过而不是先后登场。

**结尾收得住**　八行全亮后停一拍，清单与标题分层退场（每行错开 40ms），
徽记做一次缓慢「落印」呼吸，随后与 WELCOME 版式交叉淡入，最后整片浅色场
以 720ms 曲线溶解回应用。全程不缩放、不失焦 —— 全屏浅底上的模糊会显脏。

**原版读数全部留着**　上一版那套 HUD 没有丢，只是换成了哈夫克配色继续用：
左上品牌块（HAAVK / INFINITE INFORMATION / HAAVK GROUP）、下面 `REV 0.1.0 · WEB PROFILE`
加实时时钟、那一排阶段格、四角机框、暗角、档案水印、右上 `SKIP ▸`、右下 `POWERED BY HAAVK`，
以及状态条里的 `[ 05 / 06 ] VERIFY` 计数（每一步跟着跳）。散场时它们和清单一起分层收掉，
不是被一刀切掉。

**原生启动壳也同源（1.7.0 起，1.8.0 同步修版式）**　桌面端在网页层之前还有一层插件注入不进去的原生画面
（`Resources/splash.html`，原本是白底黑鲸鱼）。这一版把它重写成同一套哈夫克蓝白：
同一个 `MARK_PATH` 菱形、同一组 `--p-*` 变量、同样的描边 → 落墨 → 字标逐字母上浮，
四角刻度、右侧标尺、底部 `[ 03 / 03 ] LOAD · 47ms · CN UID · 状态条` 与细进度线全都在，
另外补了右侧 `BOOT SEQUENCE` 阶段表（逐行点亮）、左下 `LINK SIGNAL` 波形、
右下 `NODE MATRIX` 状态格。`safe-mode` / `plugin-recovery` / `web-import`
三张原生页也一起从纯中性灰换成哈夫克色板。文件放在仓库 `desktop-shell/`，
覆盖办法见 [DESKTOP.md](DESKTOP.md#五原生启动壳170-新增)。
1.8.0 把这一层也跟着修了：右侧标尺原来被写成一根实心柱子（渐变方向用错），
`NODE MATRIX` 又和标尺压线，两处一并改好；窄窗（≤1100px 或高度 ≤620px）
直接收起状态格，先保阶段表与标题。

**可交互，不是播片**　第一、二步要你点按钮或按 Enter 才会继续（可以关掉）。
右上角有跳过按钮，Esc 也能跳。

**中文主字 + 英文等宽副标题**　英文副标题逐字打出来，像终端在接收数据。

**真声台词 + 界面音效**　五句台词和终幕欢迎语都是真声素材，界面音效取自同一段素材。
浏览器要求先有一次点击才准出声，所以点过按钮之后才会听到声音。

**语音没播完不会推进**　每一步停留多久由实际音频时长决定。你点得快也不会把语音掐断。

**三十项设置**　身份名称、编号、权限等级、配色、速度、音色、语速、
开口留白、每处文案……都能在设置页实时改，改完立即生效。

---

## 播放序列

| # | 中文主字 | 英文副标题 | 需要操作 |
|---|---|---|---|
| 1 | 需要访问许可 | `ACCESS PERMISSION REQUIRED` | 点按钮 / 按 Enter / 空格 |
| 2 | 身份资料确认 | `IDENTITY VERIFICATION` | 点按钮 / 按 Enter / 空格 |
| 3 | 接收访问需求 | `ACCESS REQUEST RECEIVED` | 自动 |
| 4 | 开始读取权限 | `PERMISSION READ STARTED` | 自动 |
| 5 | 读取完毕 · 核验通过 | `READ COMPLETE · VERIFIED` | 自动 |
| 6 | 欢迎「身份名称」访问 | `WELCOME, NAME` | 自动 |

---

## 桌面端原生启动壳

桌面端（DeepSeek Harness Desktop）有两层启动画面：

| 层 | 文件 | 谁能改 |
|---|---|---|
| 网页层 | 插件注入的 `#dsh-startup-root` | 插件自己 |
| **原生层** | `Resources/splash.html` 等四张页 | 只能覆盖文件 |

原生层由 Electron 主进程 `showSplash()` 直接加载，插件注入不到，所以它在 1.7.0
之前一直是白底黑鲸鱼。`desktop-shell/` 里放的是已经改成哈夫克同款的四份文件
（`splash.html` / `safe-mode.html` / `plugin-recovery.html` / `web-import.html`），
复制进应用包的 `Contents/Resources/` 即可，具体命令、签名注意事项、以及
「桌面端自动更新会覆盖这四个文件」这条限制写在 **[DESKTOP.md](DESKTOP.md)**。

---

## 安装

**方式一 · 直接从本仓库安装**（推荐，拿到最新代码）

```bash
git clone https://github.com/YUNvexoxo/dsh-haavk.git
cd dsh-haavk
npm pack                                                  # 生成 dsh-haavk-1.8.0.tgz
dsh plugin --profile web add ./dsh-haavk-1.8.0.tgz
```

**方式二 · 从 Release 下载**　到 [Releases](https://github.com/YUNvexoxo/dsh-haavk/releases)
下载 `dsh-haavk-1.8.0.tgz`，然后 `dsh plugin --profile web add ./dsh-haavk-1.8.0.tgz`。

### 环境要求

| 项 | 要求 |
|---|---|
| 宿主 | DeepSeek Harness，`web` profile（桌面端另见 [DESKTOP.md](DESKTOP.md)） |
| Node | **>= 20** |
| 依赖 | **无**，不需要 `npm install` |
| 操作系统 | macOS / Windows / Linux 均可（插件本身就是 HTML+CSS+JS） |
| 浏览器 | 任意现代浏览器（Chrome / Edge / Safari / Firefox） |

### Windows 安装

仓库已经按 Windows 习惯处理好：脚本是 **CRLF 行尾**、`.ps1` 带 UTF-8 BOM（避免
PowerShell 5.1 下中文乱码）、`.gitattributes` 保证克隆下来行尾不会被打乱。

**① 双击 `安装.cmd`（最省事）**

解压后双击即可。脚本会自动：找 `dsh` → 找包（`package.json` / `*.tgz`）→
检测 `%USERPROFILE%\.dsh\profiles` 下的 web / desktop profile → 装进检测到的每一个。

**② PowerShell**

```powershell
# 在解压后的插件目录里
.\install.ps1                     # 自动检测并安装
.\install.ps1 -Profile web        # 只装 web profile
.\install.ps1 -Profile desktop    # 只装 desktop profile（先完全退出桌面端）
.\install.ps1 -Pkg .\dsh-haavk-1.8.0.tgz   # 指定包
```

> 首次执行若提示脚本被禁止运行，用
> `powershell -ExecutionPolicy Bypass -File .\install.ps1` 绕一次即可。

**③ 手动**

```powershell
git clone https://github.com/YUNvexoxo/dsh-haavk.git
cd dsh-haavk
npm pack
dsh plugin --profile web add .\dsh-haavk-1.8.0.tgz
```

**④ 不装插件也能看**：双击 `打开预览.cmd`（或 `.\open-preview.ps1`）直接打开离线预览页。

Windows 上的几个注意点：

- `dsh` 必须在 PATH 里（`npm i -g @deepseek-ai/dsh` 装完若提示找不到，
  重开一个终端让 PATH 生效）；
- 路径分隔符两种都行，PowerShell 里 `.\dsh-haavk-1.8.0.tgz` 和
  `./dsh-haavk-1.8.0.tgz` 等价；
- **桌面端（DeepSeek Harness Desktop）装插件前要完全退出**，profile 加锁期间装不进去；
- 如果中文显示成方块，是终端代码页问题，`chcp 65001` 切到 UTF-8 即可（`安装.cmd` 已自带）。

### 装完重启

**关掉 dsh web 的启动器窗口，再重新双击。** 只刷新页面不够 —— 插件是 Host 侧注入，
进程重启后才会挂上路由。重启后刷新页面就能看到启动动画，设置页里会多出一项「启动动画」。

### 卸载

```bash
dsh plugin --profile web remove dsh-haavk          # macOS / Linux
```
```powershell
dsh plugin --profile web remove dsh-haavk          # Windows
dsh plugin --profile desktop remove dsh-haavk      # Windows 桌面端
```

---

## 设置选项

装好后进入 **DSH 设置页 →「启动动画」**。

### 播放

| 选项 | 默认 | 作用 |
|---|---|---|
| 启用 | 开 | 总开关，关掉就完全不播 |
| 显示模式 | 每次会话 | `每次会话` 一个浏览器会话播一次 / `总是` 每次刷新都播 / `每天` 一天一次 |
| 主题 | 浅蓝 | `浅蓝` 哈夫克终端原色 / `暗色` 深蓝底板（同一套版式，只换底板与字色） |
| 速度 | 1× | 整段动画的快慢，0.35 – 3 倍 |
| 要求确认 | 开 | 第 1、2 步是否等你点按钮才继续 |
| 允许跳过 | 开 | 是否显示右上角跳过按钮、是否响应 Esc |

### 身份资料

| 选项 | 默认 | 作用 |
|---|---|---|
| 身份名称 | `哈夫克` | 终幕「欢迎 xxx 访问」里的名字 |
| 身份编号 | `HAAVK-01` | 身份核验用的编号 |
| 权限等级 | `4` | 权限等级读数 |

### 语音

| 选项 | 默认 | 作用 |
|---|---|---|
| 语音播报 | 开 | 是否念台词 |
| 语音来源 | 真声素材 | `真声素材` 用内置录音 / `系统 TTS` 用浏览器合成音 |
| 音色 | 自动 | 只在用系统 TTS 时有效。留空 = 自动挑一个女声 |
| 语速 | 0.88 | 只在用系统 TTS 时有效。越慢越有旁白感 |
| 音调 | 0.85 | 只在用系统 TTS 时有效。调低更沉稳，1.0 以上会像客服播报 |
| 音量 | 0.9 | 台词音量 |
| 播报前提示音 | 开 | 念台词前先响两声轻提示，更像系统播报 |
| 开口前留白 | 240 ms | 提示音响过之后停多久再开口，0 – 1200 ms |

### 界面音效

| 选项 | 默认 | 作用 |
|---|---|---|
| 界面音效 | 开 | 文字出现、阶段推进、按钮确认的「哒」声 |
| 音效音量 | 0.5 | 界面音效音量（不影响台词） |

> 「音效」这一个开关在设置页里出现了两次（「播放」分组里一次、「语音与音效」分组里一次），
> 两处绑的是同一个值，改哪边都一样 —— 这是上游遗留的排版，功能上没有区别。
> 配置文件里另有 `sfx`（音效来源：内置素材 / 现场合成）字段，设置页没暴露，可手改 `dsh-startup.json`。

### 视觉

| 选项 | 默认 | 作用 |
|---|---|---|
| 强调色 | `#2362af` | 哈夫克主蓝（阶段条 / 进度线 / 高亮） |
| 故障色 B · 深蓝 | `#16324f` | 回退序列色散故障用的深蓝（故障色 A 固定 `#5b96dd`，不开放） |

### 文案

| 选项 | 默认 | 作用 |
|---|---|---|
| 品牌三行 | `HAAVK` / `INFINITE INFORMATION` / `HAAVK GROUP` | 回退序列左上角品牌块 |
| 黑幕三行 | `哈夫克` / `HAAVK` / `HAAVK GROUP` | 回退序列开场黑幕上的字 |
| 终幕方框 | `HAAVK` | 终幕中央字标 |
| 页脚 | `POWERED BY HAAVK` | 右下角页脚 |

---

## 目录结构

```
dsh-haavk/
├── lib/                     插件本体
│   ├── index.js             Host 半侧：路由注册、配置读写、注入片段
│   ├── client.js            浏览器半侧：设置页「启动动画」+ 自举兜底
│   ├── splash.js            启动动画运行时（零依赖，预览页与线上同一份）
│   ├── splash.css           全部样式（portal 终端主题 + 上游旧序列）
│   └── assets/              人声 / 界面音效 / 备选图像素材
├── desktop-shell/           桌面端原生层四张页（需手工覆盖，见 DESKTOP.md）
├── preview/index.html       离线预览页（带控制台，不装插件也能完整播一遍）
├── test/                    七套冒烟测试（357 项断言，零依赖）
├── docs/                    使用文档 / 项目介绍 / 差异清单 / 截图
├── 安装.cmd  install.ps1                     Windows 安装（双击 / PowerShell）
├── 打开预览.cmd  open-preview.ps1  open-preview.sh     离线预览
├── cordis.patch.yml         插件挂载声明（`dsh plugin add` 时被应用）
├── DESKTOP.md  INSTALL.md  AUDIO-FIELDS.md  补充文档
└── package.json
```

---

## 常见问题

| 现象 | 原因 / 处理 |
|---|---|
| 刷新后没有动画 | 没装成或没重启。`curl -i http://127.0.0.1:43129/dsh-startup/splash.js` → **401 = 路由已注册（正常）**，**404 = 没装或没重启** |
| 装完还是老样子 | 只刷新了页面。Host 侧注入需要**重启 dsh web 进程**才生效 |
| 播了两次 / 启动就报错 | `~/.dsh/profiles/<profile>/cordis.patch.yml` 里还留着手工加的 `insert` 条目，删掉 |
| 没有声音 | 浏览器要求先有一次用户点击才允许出声，冷启动静默是正常的；点一次页面后从下次刷新起能听到 |
| 动画停在某一步 | 「需要人工确认」开着 → 点按钮或按 `Enter` / `Space`；或语音没播完（关掉「女声播报」） |
| 看起来卡住 | 按 `Esc` 可直接跳过；9 秒兜底也会自动摘掉根节点 |
| 桌面端启动壳还是白底鲸鱼 | 原生层要覆盖文件，插件管不到，见 [DESKTOP.md](DESKTOP.md) |
| 中文显示成方块 | 终端代码页不是 UTF-8：`chcp 65001` |
| 想彻底关掉 | 设置页关「启用启动动画」，或 `dsh plugin --profile web remove dsh-haavk` |

---

## 开发与自测

改样式不用装插件，直接开预览页：

```bash
open preview/index.html        # macOS
start preview\index.html       # Windows
```

预览页与线上共用同一份 `lib/splash.js` / `lib/splash.css`，右上角控制台能实时改
身份名称、权限等级、主题与速度。

```bash
npm test      # 七套冒烟测试，357 项断言，零依赖，node >= 20
```

| 套件 | 断言 | 覆盖 |
|---|---|---|
| `smoke-host.mjs` | 59 | 路由注册、配置校验与夹取、注入片段、生命周期 |
| `smoke-splash.mjs` | 70 | 最小 DOM 桩跑完整序列、选择器齐全、CSS 锚点 |
| `smoke-client.mjs` | 40 | 设置面板渲染与字段读写 |
| `smoke-desktop-boot.mjs` | 45 | 桌面端 `selfBoot` 兜底、自举失败回滚 |
| `smoke-desktop-shell.mjs` | 48 | 原生壳无外链、色板逐 token 相等、徽记路径一致、时间轴错峰、减动效兜底 |
| `smoke-windows.mjs` | 52 | `.cmd`/`.ps1` 行尾与 BOM、`.gitattributes`、两个安装入口一致、README 截图引用可解析 |
| `smoke-notice.mjs` | 43 | 二次开发声明：NOTICE 要素齐全、LICENSE 双版权行、`package.json` 的 `upstream`、全仓没有错误的上游仓库名 |

改完想装机验证：`npm pack` → `dsh plugin --profile web add ./dsh-haavk-1.8.0.tgz`。

---

## 来源与二次开发声明

本仓库是 [`6shenhonghong9/dsh-startup-screen`](https://github.com/6shenhonghong9/dsh-startup-screen)（MIT，v1.1.1，作者沈宏宏）的**二次开发作品**。

| | |
|---|---|
| 上游 | [6shenhonghong9/dsh-startup-screen](https://github.com/6shenhonghong9/dsh-startup-screen) · v1.1.1 · MIT · 沈宏宏 |
| 本仓库 | [YUNvexoxo/dsh-haavk](https://github.com/YUNvexoxo/dsh-haavk) · 二次开发 · MIT |
| 上游署名 | `Copyright (c) 2026 沈宏宏`，保留在 [LICENSE](LICENSE) 第一行 |
| 二次开发署名 | `Copyright (c) 2026 YUNvexoxo`，新增在 LICENSE 第二行 |
| 再分发要求 | 必须同时保留两条版权声明与 MIT 全文 |
| 不覆盖 | 哈夫克 / HAAVK /《三角洲行动》素材与商标、`lib/assets/` 音频 |

改动对照见 [docs/UPSTREAM-DIFF.md](docs/UPSTREAM-DIFF.md)；完整声明与免责见 [NOTICE](NOTICE)。

本项目分两段血统，说清楚免得误会：

**底座来自 `6shenhonghong9/dsh-startup-screen`（MIT，v1.1.1）。**
那是一位叫沈宏宏的作者做的 DeepSeek Harness 启动动画插件：黑幕 DeepSeek 鲸鱼标识 →
过曝洗白 → 暖白「技术档案」底板 → 五步交互式访问授权 → 色散故障揭幕。
Host/Client 两半的结构、路由注入、设置面板、四套冒烟测试、素材槽位协议
（`AUDIO-FIELDS.md`）、桌面端 `selfBoot` 兜底，全部出自那一版。
`LICENSE` 的 MIT 全文与原作者署名、`package.json` 的 `license: "MIT"` 都予以保留；`package.json` 另加 `upstream` 字段指回原项目，`repository` 指向本仓库。

**视觉与序列是本仓库重做的。** 从 v1.2.1 起，主题改为《三角洲行动》哈夫克（HAAVK）阵营：
黑幕换成 HAAVK 菱形徽记、暖白底板换成哈夫克蓝白、六幕授权文案换成哈夫克语境。
v1.5.0 起整体重写为「哈夫克全域互联终端」版式，v1.6.0 把过渡与结尾又重做了一遍。
这部分（`lib/splash.css` 的 portal 段、`lib/splash.js` 的 `runPortal` 分支、终端版式与动效）
是本仓库原创。

**素材与商标的权利不在本项目。** 哈夫克 / HAAVK / 《三角洲行动》的相关标识、
以及 `lib/assets/` 下的音频，权利均归原权利人（腾讯 / 天美工作室群）。
本项目是粉丝向的个人作品，与权利人没有任何关联或授权关系，详见下方免责声明。

---

## 版本迭代

从 1.2.1 到现在，顺序如下。「底座」列标出该版本有没有动到上游遗留的骨架
（Host 注入、路由、设置面板、旧序列 `run()`）。

| 版本 | 主题 | 主要改动 | 底座 |
|---|---|---|---|
| 1.1.1 | 原版 | 上游初版：DeepSeek 鲸鱼标识 → 暖白技术档案 → 五步授权 → 色散揭幕 | — |
| 1.2.1 | 哈弗克 HAVOC | 换黑幕徽记与文案为 HAVOC 语境，品牌三行改 HAVOC / INFINITE INFORMATION / HAVOC GROUP | 沿用 |
| 1.3.0 | 哈夫克 HAAVK | 徽记从「HAVOC」改为官方 HAAVK 菱形（`MARK_PATH` 按 logo 逐像素描摹），全部文案与身份号改 HAAVK | 沿用 |
| 1.3.1 | 哈夫克 HAAVK | 修终幕人声与「欢迎 XX 访问」打架：终幕不出人声，只留界面音效，身份名称可自由改 | 沿用 |
| 1.3.2 | 哈夫克 HAAVK | 默认值改为无人声、无音效、不等待确认（`requireInteraction` / `sound` / `voice` 全 false），开箱即自动播完 | 沿用 |
| 1.3.3 | 哈夫克 HAAVK | 拆出 `waitRaw`（已折算毫秒不再二次缩放）与「无声 / 无交互节奏补偿」（`silentPace`） | 沿用 |
| 1.5.0 | 哈夫克终端 | **版式重写**：暖白技术档案 → 哈夫克全域互联终端（左徽记 / 右八行清单 / 底部状态条）。配色全站统一为哈夫克蓝白，去掉橙与暖白 | 重做主题层 |
| 1.5.1 | 哈夫克终端 | 收尾三段化（清单分层退场 → 徽记落印 → WELCOME 交叉淡入），徽记与 WELCOME 不再同帧叠影 | 沿用 |
| 1.5.2 | 哈夫克终端 | 颜色全面变量化（`--p-blue-rgb` 等），新增**深色变体**（同一版式只换底板与字色） | 沿用 |
| 1.5.3 | 哈夫克终端 | **复用原版 HUD**：品牌块、REV/时钟、阶段计数、四角机框、扫描线、暗角、水印、SKIP、页脚全部回到终端版式上 | 沿用 |
| 1.5.4 | 哈夫克终端 | **全部加过程动画**：徽记描边落墨、字标逐字母、清单逐字、进度条 rAF 追值、`55ms` 逐帧步进、八行数据流、技术栈标签、扫描光带 | 沿用 |
| 1.5.5 | 哈夫克终端 | 配色按参考图**网格取色反解**（`--p-plane-t/m/b` 上深下浅、`--p-facet-rgb` 极淡斜切）；修 settle 时水印残影、徽记虚线环居中 | 沿用 |
| 1.6.0 | 哈夫克终端 | **治「切换感」+ 填空间**：描边落墨改 `fill-opacity` 过渡、换字不再强制同步布局、数据流不重启动画；徽记 38vh→46vh；新增信号波形 / 状态格 / 滚动播报 / 徽记光晕 / 终幕同心环；整层相机推近退场。实测 949 帧最差 16.8ms | 沿用 |
| 1.7.0 | 哈夫克终端 | **原生启动壳同源化**：把桌面端那层注入不进去的 `splash.html` 重写为同一套哈夫克蓝白（同 `MARK_PATH`、同 `--p-*` 变量、描边→落墨→字标），并补上右侧 `BOOT SEQUENCE` 阶段表、左下 `LINK SIGNAL` 波形、右下 `NODE MATRIX` 状态格；`safe-mode` / `plugin-recovery` / `web-import` 三张原生页同步换色板；新增 `desktop-shell/` 与 `smoke-desktop-shell` 48 项校验 | 新增一层 |
| 1.8.0 | 哈夫克终端 | **终幕换景**：删掉用户嫌丑的三层同心圆 / 准星 / 36 刻度表盘，改为「菱形坐标」—— 把徽记轮廓本身放大成背景框（`stroke` 描边 + `pathLength="1"` 归一化 dashoffset 自己描出来），框外四向短刻度，中心 30%×40% 用 radial mask 挖透明免得线穿字；`.dsu-t-finale` 从开场挪到 settle 同一拍，退场不再有「清空后重新布景」的空档。顺手修两处 1.7.x 就有的版式 bug：右侧标尺用错渐变方向被读成一根实心柱子、`NODE MATRIX` 与标尺压线；窄窗（≤1100px）藏状态格先保信息件；补齐**二次开发声明**（新增 `NOTICE`、`LICENSE` 版权行扩为上游 + 二次开发两条、`package.json` 增 `upstream` 字段、新增 `smoke-notice` 43 项校验），并修正全局更名时被误改的上游仓库名 | 沿用 |

每一版的 `.tgz` 都在仓库根目录留着，可以直接 `dsh plugin add` 任意一版回退对比。

---

## 免责声明

**一、仅供学习交流。** 本项目为个人学习与娱乐性质的开源插件，不用于任何商业目的。

**二、第三方素材权利。** 本项目的视觉风格参考自动画作品，音频素材（人声与音效）
取自第三方视频，相关权利均归原权利人所有。本项目不对上述风格与素材主张任何权利，
亦未获得任何形式的授权或背书。

**三、二次创作风险自担。** 任何人基于本项目进行修改、改编、翻译、再分发等二次创作，
由此产生的侵权、纠纷或任何法律责任，均由该行为人自行承担，与本项目作者无关。

**四、商业使用风险自担。** 本项目**未授权任何商业用途**。若将本项目或其衍生作品
用于商业行为（包括但不限于售卖、付费分发、商业产品集成、商业宣传、商业演示），
由此引发的知识产权纠纷与全部法律责任，由使用者自行承担，作者不承担任何责任。

**五、许可范围。** 本项目的开源许可仅覆盖作者原创的代码与文案，
**不覆盖**上述第三方风格与素材。使用者在再利用第三方内容时，应自行取得相应授权。

**六、权利主张。** 若权利人认为本项目侵犯了其合法权益，请联系作者，
作者将在核实后立即移除相关内容。

---

## License

MIT © 沈宏宏
